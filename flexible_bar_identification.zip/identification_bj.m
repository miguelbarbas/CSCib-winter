%% Plant model identification - Box-Jenkins methodology
% Flexible bar, lab guide Section 4 (sessions L5-L7).
%
% Follows the structure of the identification script in the guide:
%   read .mat data -> bar tip angle -> differentiate + filter -> detrend
%   -> ARMAX -> polydata -> add integrator (conv) -> tf2ss -> A, B, C, D
%
% The choice of the ARMAX orders is done with the Box-Jenkins iterative
% cycle instead of plain trial and error:
%   1. Identification  - use the data (correlation analysis, spectral
%                        estimate, ARX order scan) to pick the delay and a
%                        range of plausible orders
%   2. Estimation      - fit every candidate ARMAX model in that range
%   3. Diagnostics     - residual whiteness, residual/input independence,
%                        parameter significance, pole/zero cancellations,
%                        stability, non-minimum phase zero, fit on the
%                        validation set
%   4. Selection       - the most parsimonious model that passes the
%                        checks and is within tolFit of the best
%                        validation fit
%
% Output (workspace and model_bj.mat): A, B, C, D, Ts, th

clear; close all; clc;

%% 0. Parameters
Ts       = 0.02;      % sampling interval [s] (50 Hz)
Kp       = -32.99;    % potentiometer constant [deg/V] (our calibration)
Ke       = 3.97;      % strain gage constant [deg/V] (our calibration)
af       = 0.8;       % pole of the low-pass filter
tDiscard = 5;         % initial seconds thrown away (transient)

idFiles = {'exp2_quad_1V.mat', 'exp2_rand_1V.mat'};  % 1V identification data
valFile = 'exp2_val_1V.mat';                         % kept aside for validation

% Order search range for the estimation step. naRange and nbRange are set
% in section 2d from the ARX order scan; nkRange in section 2a.
ncRange = 1:6;

maxLag = 25;     % lags used in the residual tests
alpha  = 0.01;   % significance level of the residual tests
tolFit = 1;      % accepted loss of validation fit [percentage points]

% Folder with the .mat files. When a single section is run (Ctrl+Enter),
% mfilename points to a temporary editor file, not to this script, so
% the candidates are tried in order until one holds the data.
candDirs = {fileparts(mfilename('fullpath')), ...
            fileparts(which('identification_bj')), pwd};
dataDir = '';
for k = 1:numel(candDirs)
    if ~isempty(candDirs{k}) && isfile(fullfile(candDirs{k}, idFiles{1}))
        dataDir = candDirs{k};
        break
    end
end
if isempty(dataDir)
    error(['Cannot find %s. Change the current folder (cd) to the folder ' ...
        'with the data, or add it to the path.'], idFiles{1});
end
fprintf('Data folder: %s\n', dataDir);

%% 1. Read the data and process it
% Differentiation removes the motor integrator; the low-pass filter
% attenuates the high-frequency noise amplified by the derivative:
%   F(z) = (1-af)(1-z^-1) / (1-af z^-1)
Afilt = [1 -af];
Bfilt = (1-af)*[1 -1];

nId  = numel(idFiles);
zId  = cell(1, nId);
rawId = cell(1, nId);
for k = 1:nId
    [zId{k}, rawId{k}] = loadExperiment(fullfile(dataDir, idFiles{k}), ...
        Ts, Kp, Ke, Afilt, Bfilt, tDiscard);
end
[zval, rawVal] = loadExperiment(fullfile(dataDir, valFile), ...
    Ts, Kp, Ke, Afilt, Bfilt, tDiscard);

% Both identification experiments are used together (multi-experiment data)
zest = merge(zId{:});
zest.ExperimentName = erase(idFiles, '.mat');

% Raw signals, as in Figure 11 of the guide
figure('Name', 'Raw data');
allRaw = [rawId, {rawVal}];
allNames = [idFiles, {valFile}];
for k = 1:numel(allRaw)
    r = allRaw{k};
    subplot(3, numel(allRaw), k);
    plot(r.t, r.utrend); grid on; ylabel('u [V]');
    title(allNames{k}, 'Interpreter', 'none');
    subplot(3, numel(allRaw), k + numel(allRaw));
    plot(r.t, r.thetae*Kp); grid on; ylabel('\theta [deg]');
    subplot(3, numel(allRaw), k + 2*numel(allRaw));
    plot(r.t, r.alphae*Ke); grid on; ylabel('\alpha [deg]'); xlabel('Time [s]');
end

% Processed signals used for identification
figure('Name', 'Processed data');
for k = 1:nId
    subplot(nId, 1, k);
    zk = zId{k};
    yyaxis left;  plot(zk.SamplingInstants, zk.OutputData); ylabel('y_f [deg/sample]');
    yyaxis right; plot(zk.SamplingInstants, zk.InputData);  ylabel('u [V]');
    grid on; title(idFiles{k}, 'Interpreter', 'none');
end
xlabel('Time [s]');

%% 2. Box-Jenkins step 1: model identification (structure from the data)

% 2a. DELAY ESTIMATION FROM DATA. 

% The range for k search is defined by combining
% the lag at which the input first affects the output and the lag at which
% the output stops undershooting.

irEst = impulseest(zest, 50);
[h, ~, ~, hsd] = impulse(irEst);
firstLag = find(abs(h(2:end)) > 2.58*hsd(2:end), 1);
if isempty(firstLag), firstLag = 1; end
try
    nkEst = delayest(zest);
catch
    nkEst = firstLag;
end
nkRange = min(firstLag, nkEst):max(firstLag, nkEst);
fprintf('First significant impulse response lag = %d, delayest = %d\n', ...
    firstLag, nkEst);

% 2b. CORRELATION ANALYSIS

% Estimated impulse response from data 

figure('Name', 'Correlation analysis');
subplot(2,1,1);
h = impulseplot(irEst);
showConfidence(h, 2.58);
title('Impulse response estimate (99% confidence)');

% Autocorrelation of the output from data

subplot(2,1,2);
stem(0:maxLag, [1; autocorrLags(zId{1}.OutputData, maxLag)], 'filled'); grid on;
xlabel('Lag [samples]'); ylabel('r_{yy}');
title(sprintf('Autocorrelation of y_f (%s)', idFiles{1}), 'Interpreter', 'none');

% 2c. SPECTRAL ANALYSIS

% Estimated frequency response from data 

gSpa = spa(zest);
figure('Name', 'Spectral estimate');
bode(gSpa); grid on;
title('Spectral analysis estimate of F(z)G(z)');

% Sections 2c and 2b give a qualitative estimate for the number and locations of 
% poles and zeros of the filtered model 

% 2d. MODEL ORDER ESTIMATE FROM AIC.

% The Akaike Information Criterion (AIC) is used to estimate the model
% order from the data.

V = arxstruc(zest, zval, struc(1:8, 1:6, nkEst));
nnARX = selstruc(V, 'aic');
naRange = 1:nnARX(1);
nbRange = 1:nnARX(2);
fprintf('ARX order scan (AIC on validation data): na = %d, nb = %d\n', ...
    nnARX(1), nnARX(2));
fprintf('ARMAX search: na = 1..%d, nb = 1..%d, nc = 1..%d, nk = %d..%d (%d models)\n', ...
    naRange(end), nbRange(end), ncRange(end), nkRange(1), nkRange(end), ...
    numel(naRange)*numel(nbRange)*numel(ncRange)*numel(nkRange));

%% 3. Box-Jenkins steps 2 and 3: estimation and diagnostic checking
cand = [];
for na = naRange
    for nb = nbRange
        for nc = ncRange
            for nk = nkRange
                cand(end+1, :) = [na nb nc nk]; %#ok<SAGROW>
            end
        end
    end
end
nCand = size(cand, 1);

opt = armaxOptions('InitialCondition', 'backcast');  % 'estimate' is not allowed with multi-experiment data
models   = cell(nCand, 1);
nPar     = zeros(nCand, 1);
fitEst   = zeros(nCand, 1);
fitVal   = zeros(nCand, 1);
bic      = zeros(nCand, 1);
pWhite   = zeros(nCand, 1);
pCross   = zeros(nCand, 1);
nInsig   = zeros(nCand, 1);
cancel   = false(nCand, 1);
stable   = false(nCand, 1);
nmp      = false(nCand, 1);

fprintf('Estimating %d ARMAX candidates (takes a few minutes)...\n', nCand);
ws = warning('off', 'all');   % poor candidates flood the window with initial-state warnings
for i = 1:nCand
    nn = cand(i,:);
    m  = armax(zest, nn, opt);
    models{i} = m;

    nPar(i)   = sum(cand(i,1:3));
    fitEst(i) = simFit(zest, m);
    fitVal(i) = simFit(zval, m);
    bic(i)    = aic(m, 'BIC');

    % Residual tests on the estimation data (worst experiment counts)
    e = pe(zest, m);
    pw = zeros(nId, 1);  pc = zeros(nId, 1);
    for k = 1:nId
        ek = getexp(e, k);  zk = getexp(zest, k);
        [pw(k), pc(k)] = residualTests(ek.OutputData, zk.InputData, ...
            maxLag, cand(i,1) + cand(i,3));
    end
    pWhite(i) = min(pw);
    pCross(i) = min(pc);

    % Parameters whose 95% interval contains zero
    [pv, sd] = getpvec(m, 'free');
    nInsig(i) = sum(abs(pv) < 1.96*sd);

    % Stability and near pole/zero cancellations of B/A
    [Ap, Bp] = polydata(m);
    poles = roots(Ap);
    zrs   = roots(Bp(find(Bp, 1):end));
    stable(i) = all(abs(poles) < 1);
    if ~isempty(zrs)
        dist = abs(zrs(:) - poles(:).');
        cancel(i) = min(dist(:)) < 0.05;
        % Non-minimum phase zero: real and greater than 1 (initial
        % undershoot of the bar tip, it moves backwards first)
        nmp(i) = any(abs(imag(zrs)) < 1e-6 & real(zrs) > 1);
    end
end
warning(ws);

Results = table(cand(:,1), cand(:,2), cand(:,3), cand(:,4), nPar, fitEst, ...
    fitVal, bic, pWhite, pCross, nInsig, stable, cancel, nmp, ...
    'VariableNames', {'na','nb','nc','nk','nPar','FitEst','FitVal','BIC', ...
    'pWhite','pCross','nInsig','Stable','Cancel','NMPzero'});

%% 4. Box-Jenkins step 4: model selection
% A model is adequate when its residuals are white and independent of the
% input, all parameters are significant, it has no pole/zero cancellation,
% it is stable and it has the non-minimum phase zero the physics requires
% (the tip moves backwards before following the motor). Real data (dead
% zone, backlash, cable) often makes every candidate fail the whiteness
% test, so the checks are relaxed in order from the least to the most
% important one until some model passes. The last check is never relaxed.
checks = { ...
    'residual whiteness',          pWhite > alpha; ...
    'residual/input independence', pCross > alpha; ...
    'parameter significance',      nInsig == 0; ...
    'no pole/zero cancellation',   ~cancel; ...
    'stability',                   stable; ...
    'non-minimum phase zero',      nmp};

ok = true(nCand, 1);
for c = 1:size(checks, 1), ok = ok & checks{c, 2}; end
relaxed = {};
c = 1;
while ~any(ok) && c < size(checks, 1)
    relaxed{end+1} = checks{c, 1}; %#ok<SAGROW>
    ok = true(nCand, 1);
    for j = c+1:size(checks, 1), ok = ok & checks{j, 2}; end
    c = c + 1;
end
if ~isempty(relaxed)
    fprintf('No candidate passes every check; relaxed: %s\n', strjoin(relaxed, ', '));
end
Results.Adequate = ok;

% Parsimony: fewest parameters among adequate models within tolFit of the
% best validation fit; ties broken by BIC
bestVal = max(fitVal(ok));
pool    = find(ok & fitVal >= bestVal - tolFit);
[~, o]  = sortrows([nPar(pool) bic(pool)]);
bestIdx = pool(o(1));

th = models{bestIdx};
na = cand(bestIdx,1);  nb = cand(bestIdx,2);  nc = cand(bestIdx,3);  nk = cand(bestIdx,4);

top = sortrows(Results(ok, :), 'FitVal', 'descend');
disp(top(1:min(15, height(top)), :));
fprintf('\n--- Selected ARMAX model ---\n');
fprintf('[na nb nc nk] = [%d %d %d %d]\n', na, nb, nc, nk);
fprintf('Fit estimation = %.2f %%, fit validation = %.2f %% (best %.2f %%)\n', ...
    fitEst(bestIdx), fitVal(bestIdx), bestVal);
fprintf('BIC = %.1f, Ljung-Box p = %.3f, cross-corr p = %.3f\n', ...
    bic(bestIdx), pWhite(bestIdx), pCross(bestIdx));

% Validation fit versus complexity
figure('Name', 'Model selection');
scatter(nPar(~ok), fitVal(~ok), 25, [0.6 0.6 0.6]); hold on;
scatter(nPar(ok), fitVal(ok), 25, 'b', 'filled');
plot(nPar(bestIdx), fitVal(bestIdx), 'rp', 'MarkerSize', 14, 'MarkerFaceColor', 'r');
yline(bestVal - tolFit, '--', 'tolerance');
ylim([max(min(fitVal(ok)) - 5, 0), 100]);   % diverging candidates have fits near -Inf
grid on; hold off;
xlabel('na + nb + nc'); ylabel('Validation fit [%]');
legend({'failed checks', 'adequate', 'selected'}, 'Location', 'southeast');
title('ARMAX order selection');

% Residual analysis of the selected model
figure('Name', 'Residual analysis');
resid(zest, th);

%% 5. Validate before adding the integrator (as in the guide)
[den1, num1] = polydata(th);

u  = zval.InputData;
yf = zval.OutputData;
yfsim = filter(num1, den1, u);   % equivalent to idsim(u, th)

figure('Name', 'Differentiated output');
tv = zval.SamplingInstants;
plot(tv, yf, tv, yfsim); grid on;
xlabel('Time [s]'); ylabel('Differentiated angle [deg/sample]');
legend('validation data', 'model');
title(sprintf('Validation (%s), fit %.1f %%', valFile, fitVal(bestIdx)), ...
    'Interpreter', 'none');

figure('Name', 'Compare');
compare(zval, th);

%% 6. Add the integrator and convert to a state model
[num, den] = eqtflength(num1, conv(den1, [1 -1]));
[A, B, C, D] = tf2ss(num, den);

fprintf('\nState model of order %d. Eigenvalues of A:\n', size(A, 1));
disp(eig(A));
if min(abs(eig(A) - 1)) > 1e-6
    warning('No eigenvalue at 1: the integrator is missing.');
end

%% 7. Validate the full model on the validation set (L6)
% The state model is simulated with the raw validation input and compared
% with the measured tip angle. The input is NOT detrended: a nonzero mean
% of u makes the bar really rotate, and the model with its integrator must
% reproduce that. Only the initial angle is removed, since the simulation
% starts at zero; nothing is detrended.
sys = ss(A, B, C, D, Ts);
keep  = rawVal.keep;
ya    = rawVal.ytrend(keep) - rawVal.ytrend(find(keep, 1));
uv    = rawVal.utrend(keep);
ysim  = lsim(sys, uv);
fitAngle = 100*(1 - norm(ya - ysim)/norm(ya - mean(ya)));

figure('Name', 'Angle validation');
plot(tv, ya, tv, ysim); grid on;
xlabel('Time [s]'); ylabel('Tip angle [deg]');
legend('validation data', 'state model');
title(sprintf('Tip angle, fit %.1f %%', fitAngle));
fprintf('Angle fit on validation data = %.2f %%\n', fitAngle);

%% 8. Plots that characterise the model (L7 / Q3)
figure('Name', 'Pole-zero map');
pzmap(sys); grid on;

figure('Name', 'Frequency response');
bode(sys); grid on;

% The undershoot from the non-minimum phase zero lasts only a few samples,
% so the first 0.3 s are shown separately
figure('Name', 'Step response');
subplot(1,2,1); step(sys, 3);   grid on; title('Step response');
subplot(1,2,2); step(sys, 0.3); grid on; title('First 0.3 s (undershoot)');

damp(sys);

save(fullfile(dataDir, 'model_bj.mat'), 'A', 'B', 'C', 'D', 'Ts', 'th', ...
    'na', 'nb', 'nc', 'nk', 'af', 'Results');

%% Local functions
function [z, raw] = loadExperiment(file, Ts, Kp, Ke, Afilt, Bfilt, tDiscard)
% Reads one experiment and applies the processing of the guide.
S    = load(file);
t    = S.dados.time;
sigs = S.dados.signals.values;

utrend = sigs(:,1);   % input signal
thetae = sigs(:,2);   % potentiometer signal
alphae = sigs(:,3);   % strain gage signal

% Computation of the total bar angle
ytrend = thetae*Kp + alphae*Ke;

% Differentiation and filtering, then throw the transient away
yf   = filter(Bfilt, Afilt, ytrend);
keep = t >= tDiscard;
yf   = detrend(yf(keep));
u    = detrend(utrend(keep));

z = iddata(yf, u, Ts, 'InputName', 'u', 'OutputName', 'yf', ...
    'InputUnit', 'V', 'OutputUnit', 'deg');
raw = struct('t', t, 'utrend', utrend, 'thetae', thetae, ...
    'alphae', alphae, 'ytrend', ytrend, 'keep', keep);
end

function f = simFit(z, m)
% Simulation fit (NRMSE, %), averaged over the experiments in z.
[~, f] = compare(z, m);
if iscell(f), f = cellfun(@(x) x(1), f); end
f = mean(f);
end

function r = autocorrLags(x, maxLag)
% Normalised autocorrelation for lags 1..maxLag.
x  = x - mean(x);
N  = numel(x);
r  = zeros(maxLag, 1);
c0 = sum(x.^2);
for k = 1:maxLag
    r(k) = sum(x(1+k:N).*x(1:N-k))/c0;
end
end

function [pWhite, pCross] = residualTests(e, u, maxLag, nNoisePar)
% Ljung-Box test of residual whiteness and chi-square test of
% independence between residuals and past inputs (lags 0..maxLag).
N  = numel(e);
re = autocorrLags(e, maxLag);
Q  = N*(N+2)*sum(re.^2 ./ (N - (1:maxLag))');
pWhite = gammainc(Q/2, max(maxLag - nNoisePar, 1)/2, 'upper');

e = e - mean(e);  u = u - mean(u);
den = sqrt(sum(e.^2)*sum(u.^2));
reu = zeros(maxLag + 1, 1);
for k = 0:maxLag
    reu(k+1) = sum(e(1+k:N).*u(1:N-k))/den;
end
S = N*sum(reu.^2);
pCross = gammainc(S/2, (maxLag + 1)/2, 'upper');
end

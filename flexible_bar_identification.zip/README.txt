Flexible bar - plant model identification (CSCib lab, Section 4)
================================================================

Contents
--------
identification_summary.mlx  Live script: every step of the identification,
                            all plots, and a full description of the
                            selected model. Opens with the results already
                            shown; run it to reproduce them.
identification_bj.m         Full identification script (Box-Jenkins order
                            search over 1152 ARMAX models). Writes
                            model_bj.mat.
model_bj.mat                Results of the order search and the selected
                            model (ARMAX [6 2 1 1]), used by the live script.
exp2_quad_1V.mat            Identification data: square wave, +-1 V
exp2_rand_1V.mat            Identification data: PRBS, +-1 V
exp2_val_1V.mat             Validation data: PRBS, +-1 V (not used to fit)
exp_sinewave.mat            Independent test: sine, +-1 V, 0.4 Hz

Requirements
------------
MATLAB with:
  - System Identification Toolbox
  - Control System Toolbox
  - Signal Processing Toolbox
Made and tested with MATLAB R2026a.

How to run
----------
1. Extract the zip into a folder of its own.
2. In MATLAB, make that folder the current folder.
3. Open identification_summary.mlx and press Run (Live Editor tab).
   It takes about 2 minutes.

All files must stay in the same folder.

Options
-------
- The live script loads the order search from model_bj.mat. To repeat the
  search inside the live script, set rerunSearch = true at the top
  (about 10 minutes).
- To regenerate model_bj.mat from scratch, run identification_bj.m
  (about 10 minutes). It also saves A, B, C, D, Ts and th for the
  controller design.

Calibration constants used: Kp = -32.99 deg/V, Ke = 3.97 deg/V,
sampling period Ts = 0.02 s, filter pole af = 0.8.

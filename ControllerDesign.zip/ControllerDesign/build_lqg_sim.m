function build_lqg_sim(folder)
% Builds lqg_sim.slx: Figure 11 of the notes, the identified plant
% controlled by state feedback Kc with a current observer (Kalman gain Lc)
% and reference feedforward gain Nbar.
%
% Block parameters are the workspace variables of lqg_design.m:
% A, B, C, D, Ts, K (= Kc), M (= Lc), Nbar.
%
% In the laboratory the Plant block is replaced by the data acquisition
% blocks that interface with the real bar.

if nargin < 1, folder = fileparts(mfilename('fullpath')); end
mdl = 'lqg_sim';
if bdIsLoaded(mdl), close_system(mdl, 0); end
new_system(mdl);

set_param(mdl, 'Solver', 'FixedStepDiscrete', 'FixedStep', 'Ts', ...
    'StopTime', '40', 'SignalLogging', 'on', 'SignalLoggingName', 'logsout', ...
    'ReturnWorkspaceOutputs', 'on');

% Reference, feedforward and plant (top row)
add(mdl, 'simulink/Sources/Signal Generator', 'Signal Generator', [30 95 80 135], ...
    'WaveForm', 'square', 'Amplitude', '20', 'Frequency', '0.05', 'Units', 'Hertz');
add(mdl, 'simulink/Math Operations/Gain', 'Nbar', [130 100 180 130], ...
    'Gain', 'Nbar');
add(mdl, 'simulink/Math Operations/Sum', 'Sum u', [230 105 250 125], ...
    'Inputs', '+-', 'IconShape', 'round');
add(mdl, 'simulink/Discrete/Discrete State-Space', 'Plant', [320 90 440 140], ...
    'A', 'A', 'B', 'B', 'C', 'C', 'D', 'D', 'SampleTime', 'Ts');
add(mdl, 'simulink/Signal Routing/Mux', 'Mux', [560 85 565 145], 'Inputs', '2');
add(mdl, 'simulink/Sinks/Scope', 'Scope', [610 100 640 130]);
add(mdl, 'simulink/Sinks/Scope', 'Scope1', [320 20 350 50]);

% Current observer, eqs. (23)-(24) (green blocks of Figure 11)
add(mdl, 'simulink/Math Operations/Gain', 'B', [320 200 370 230], ...
    'Gain', 'B', 'Multiplication', 'Matrix(K*u)');
add(mdl, 'simulink/Math Operations/Sum', 'Sum xbar', [410 205 430 225], ...
    'Inputs', '++', 'IconShape', 'round');
add(mdl, 'simulink/Discrete/Unit Delay', 'Unit Delay', [470 195 510 235], ...
    'InitialCondition', 'zeros(size(A,1),1)', 'SampleTime', 'Ts');
add(mdl, 'simulink/Math Operations/Gain', 'C', [560 250 610 280], ...
    'Gain', 'C', 'Multiplication', 'Matrix(K*u)');
add(mdl, 'simulink/Math Operations/Sum', 'Sum e', [660 255 680 275], ...
    'Inputs', '+-', 'IconShape', 'round');
add(mdl, 'simulink/Math Operations/Gain', 'Lc', [720 250 770 280], ...
    'Gain', 'M', 'Multiplication', 'Matrix(K*u)');
add(mdl, 'simulink/Math Operations/Sum', 'Sum xhat', [820 205 840 225], ...
    'Inputs', '++', 'IconShape', 'round');
add(mdl, 'simulink/Math Operations/Gain', 'A', [470 320 520 350], ...
    'Gain', 'A', 'Multiplication', 'Matrix(K*u)', 'Orientation', 'left');

% State feedback (red block of Figure 11)
add(mdl, 'simulink/Math Operations/Gain', 'Kc', [470 400 520 430], ...
    'Gain', 'K', 'Multiplication', 'Matrix(K*u)', 'Orientation', 'left');

% Connections
r    = link(mdl, 'Signal Generator/1', 'Nbar/1');
       link(mdl, 'Signal Generator/1', 'Mux/1');
       link(mdl, 'Nbar/1', 'Sum u/1');
u    = link(mdl, 'Sum u/1', 'Plant/1');
       link(mdl, 'Sum u/1', 'B/1');
       link(mdl, 'Sum u/1', 'Scope1/1');
y    = link(mdl, 'Plant/1', 'Mux/2');
       link(mdl, 'Plant/1', 'Sum e/1');
       link(mdl, 'Mux/1', 'Scope/1');
       link(mdl, 'B/1', 'Sum xbar/1');
       link(mdl, 'Sum xbar/1', 'Unit Delay/1');
xbar = link(mdl, 'Unit Delay/1', 'C/1');
       link(mdl, 'Unit Delay/1', 'Sum xhat/1');
       link(mdl, 'C/1', 'Sum e/2');
       link(mdl, 'Sum e/1', 'Lc/1');
       link(mdl, 'Lc/1', 'Sum xhat/2');
xhat = link(mdl, 'Sum xhat/1', 'A/1');
       link(mdl, 'Sum xhat/1', 'Kc/1');
       link(mdl, 'A/1', 'Sum xbar/2');
       link(mdl, 'Kc/1', 'Sum u/2');

% Signal names; r, u, y are logged to logsout
names = {r, 'r'; u, 'u(k)'; y, 'y(k)'; xbar, 'xbar(k)'; xhat, 'xhat(k)'};
for k = 1:size(names, 1)
    set_param(names{k,1}, 'Name', names{k,2});
end
logged = {'Signal Generator', 'r'; 'Sum u', 'u'; 'Plant', 'y'};
for k = 1:size(logged, 1)
    ph = get_param([mdl '/' logged{k,1}], 'PortHandles');
    set_param(ph.Outport(1), 'DataLogging', 'on', ...
        'DataLoggingNameMode', 'Custom', 'DataLoggingName', logged{k,2});
end

% Block colours as in Figure 11
set_param([mdl '/Plant'], 'BackgroundColor', 'yellow');
for b = {'B', 'Sum xbar', 'Unit Delay', 'C', 'Sum e', 'Lc', 'Sum xhat', 'A'}
    set_param([mdl '/' b{1}], 'BackgroundColor', 'green');
end
set_param([mdl '/Kc'],   'BackgroundColor', 'red');
set_param([mdl '/Nbar'], 'BackgroundColor', 'cyan');

save_system(mdl, fullfile(folder, [mdl '.slx']));
fprintf('Saved %s\n', fullfile(folder, [mdl '.slx']));
end

function add(mdl, lib, name, pos, varargin)
add_block(lib, [mdl '/' name], 'Position', pos, varargin{:});
end

function h = link(mdl, from, to)
h = add_line(mdl, from, to, 'autorouting', 'smart');
end

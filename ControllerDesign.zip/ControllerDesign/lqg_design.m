%% LQG controller design - flexible bar

clear; close all; clc;

%% 0. Load the identified plant
here = fileparts(mfilename('fullpath'));
if isempty(here), here = pwd; end
S = load(fullfile(here, '..', 'Lab28-09', 'model_bj.mat'), 'A', 'B', 'C', 'D', 'Ts');
A = S.A;  B = S.B;  C = S.C;  D = S.D;  Ts = S.Ts;
n = size(A, 1);
fprintf('Plant of order %d, Ts = %g s\n', n, Ts);

%% 1. Design of the current observer and state feedback gains
% (code of the notes, page 21)

% A, B, C, D denote the state model of the process to control
% A, B, C are obtained from model identification; D = 0
% regulator gain computation using LQ expressions
Q = C'*C;
R = 500; % 100
[K,S,E] = dlqr(A,B,Q,R);
%dstep(A-B*K,B,C,D);

% estimator gain computation using Kalman filter expressions
w2 = 100;
QE = eye(size(A))*w2;
RE = 1;
G = eye(size(A));
[M,P,Z,EE] = dlqe(A,G,C,QE,RE);

% Computing reference feedforward gain according to
% (8.73) Franklin DCDS 3rd Ed
N = inv([A-eye(size(A)), B; C, 0])*[zeros(size(A,1),1);1];
Nx = N(1:end-1,:);
Nu = N(end,:);
Nbar = Nu + K*Nx;

fprintf('\nR = %g, QE = %g*I, RE = %g\n', R, w2, RE);
fprintf('Kc   = %s\n', mat2str(K, 4));
fprintf('Lc   = %s\n', mat2str(M', 4));
fprintf('Nbar = %.4f\n', Nbar);
fprintf('\nLQ closed-loop poles |z|:     %s\n', mat2str(abs(E'), 4));
fprintf('Kalman error poles |z|:       %s\n', mat2str(abs(EE'), 4));

%% 1a. Root-square locus in R (L8)
% Closed-loop eigenvalues of A - B*K(R) as R sweeps; they are the stable
% roots of R a(z)a(1/z) + b(z)b(1/z) = 0 (Chang-Letov). Small R: poles go
% to the zeros (or their mirror images); large R: to the open-loop poles.
Rsweep = logspace(-3, 6, 200);
polesR = zeros(n, numel(Rsweep));
for i = 1:numel(Rsweep)
    [~, ~, polesR(:, i)] = dlqr(A, B, Q, Rsweep(i));
end
plotLocus(polesR, Rsweep, eig(A), tzero(ss(A, B, C, D, Ts)), E, ...
    'R', sprintf('Root-square locus in R (chosen R = %g)', R));

%% 1b. State feedback only, u = Nbar*r - K*x (L8)
% The true state is fed back (no observer), for a few values of R, to see
% the speed / control effort trade-off before the observer is added.
Rlist = unique([10 100 R 5000]);
tEnd  = 5;
figure('Name', 'LQ state feedback');
fprintf('\nLQ state feedback, unit step reference:\n');
fprintf('%8s %10s %12s %12s %10s\n', 'R', 'rise [s]', 'settle [s]', 'overshoot %', 'max|u|/r');
for Ri = Rlist
    Ki   = dlqr(A, B, Q, Ri);
    Nbi  = Nu + Ki*Nx;
    Tlq  = ss(A - B*Ki, B*Nbi, [C; -Ki], [0; Nbi], Ts);   % outputs y and u
    [ylq, tlq] = step(Tlq, tEnd);
    info = stepinfo(ylq(:, 1), tlq, 1);
    fprintf('%8g %10.3f %12.3f %12.2f %10.3f\n', Ri, info.RiseTime, ...
        info.SettlingTime, info.Overshoot, max(abs(ylq(:, 2))));
    subplot(2,1,1); stairs(tlq, ylq(:, 1)); hold on;
    subplot(2,1,2); stairs(tlq, ylq(:, 2)); hold on;
end
subplot(2,1,1); hold off; grid on; ylabel('y / r');
title('State feedback (true state), unit step reference');
legend(compose('R = %g', Rlist), 'Location', 'southeast');
subplot(2,1,2); hold off; grid on; ylabel('u / r [V/deg]'); xlabel('Time [s]');

%% 1c. Observer root-square locus in Rv (L9)
% Kalman error poles (eigenvalues of A - A*M*C) as RE = Rv sweeps with
% QE fixed. Small Rv: fast observer (trusts the sensor); large Rv: the
% error poles go to the open-loop poles (trusts the model).
RVsweep = logspace(-4, 6, 200);
polesRv = zeros(n, numel(RVsweep));
for i = 1:numel(RVsweep)
    [~, ~, ~, polesRv(:, i)] = dlqe(A, G, C, QE, RVsweep(i));
end
plotLocus(polesRv, RVsweep, eig(A), [], EE, ...
    'R_v', sprintf('Observer root-square locus in R_v (Q_w = %g I, chosen R_v = %g)', w2, RE));

%% 2. Controller state model, eqs. (34)-(35)
% Input y (process output), output -u (minus the process input)
Ac = (A - B*K)*(eye(n) - M*C);
Bc = (A - B*K)*M;
Cc = K*(eye(n) - M*C);
Dc = K*M;

%% 3. Loop gain (section 9)
[numP, denP] = ss2tf(A, B, C, D);        % process
[numC, denC] = ss2tf(Ac, Bc, Cc, Dc);    % LQG controller
[numL, denL] = series(numP, denP, numC, denC);
Lqg = tf(numL, denL, Ts);

% Loop gain of the LQ controller with the true state, K(zI-A)^-1 B,
% to judge the loop gain recovery
Llq = ss(A, B, K, 0, Ts);

figure('Name', 'Loop gain');
w = logspace(-2, log10(pi/Ts), 500);
bode(Lqg, Llq, w); grid on;
legend('LQG', 'LQ (state feedback)', 'Location', 'southwest');
title('Loop gain');

[Gm, Pm, Wcg, Wcp] = margin(Lqg);
fprintf('\nLQG margins: GM = %.2f dB (at %.2f rad/s), PM = %.1f deg (at %.2f rad/s)\n', ...
    20*log10(Gm), Wcg, Pm, Wcp);

% Loop transfer recovery (L9 / L11): with QE = w2*I fixed, lowering Rv
% makes the LQG loop gain approach the LQ one
[GmLQ, PmLQ] = margin(Llq);
fprintf('\nLTR, loop gain margins (LQ with true state: GM = %.2f dB, PM = %.1f deg):\n', ...
    20*log10(GmLQ), PmLQ);
fprintf('%10s %10s %10s\n', 'Rv', 'GM [dB]', 'PM [deg]');
RVlist = [1e-2 1 1e2 1e4];
Lltr = cell(1, numel(RVlist));
for i = 1:numel(RVlist)
    Mi = dlqe(A, G, C, QE, RVlist(i));
    Ctrl = ss((A - B*K)*(eye(n) - Mi*C), (A - B*K)*Mi, K*(eye(n) - Mi*C), K*Mi, Ts);
    Lltr{i} = Ctrl*ss(A, B, C, D, Ts);
    [Gmi, Pmi] = margin(Lltr{i});
    fprintf('%10g %10.2f %10.1f\n', RVlist(i), 20*log10(Gmi), Pmi);
end
figure('Name', 'Loop transfer recovery');
bode(Lltr{:}, Llq, w); grid on;
legend([compose('LQG, R_v = %g', RVlist), {'LQ (state feedback)'}], ...
    'Location', 'southwest');
title(sprintf('Loop gain recovery (Q_w = %g I, R = %g)', w2, R));

%% 4. Transfer function of the controlled system (Figure 11)
% Loop of Figure 11 (the one simulated in lqg_sim.slx): the observer is
% driven by the whole u = Nbar*r - Kc*xhat. State [x; xbar]:
%   xhat = (I - Lc C) xbar + Lc C x
Acl = [A - B*K*M*C,       -B*K*(eye(n) - M*C);
       (A - B*K)*M*C,     (A - B*K)*(eye(n) - M*C)];
Bcl = [B; B]*Nbar;
Ccl = [C, zeros(1, n)];
T = ss(Acl, Bcl, Ccl, 0, Ts);

fprintf('Static gain of the controlled system = %.4f\n', dcgain(T));
fprintf('Closed-loop bandwidth = %.2f rad/s\n', bandwidth(T));
fprintf('Closed-loop poles |z| (LQ + Kalman, separation): %s\n', ...
    mat2str(sort(abs(eig(Acl)))', 4));

figure('Name', 'Controlled system');
bode(T, w); grid on;
title('Controlled system r \rightarrow y');

figure('Name', 'Step response');
step(T, 5); grid on;
title('Controlled system step response');

%% 5. Simulink simulation (Figure 11 of the notes)
mdl = 'lqg_sim';
if ~isfile(fullfile(here, [mdl '.slx']))
    build_lqg_sim(here);
end
out = sim(fullfile(here, [mdl '.slx']));

ysim = out.logsout.get('y').Values;
rsim = out.logsout.get('r').Values;
usim = out.logsout.get('u').Values;
figure('Name', 'Simulink simulation');
subplot(2,1,1);
stairs(rsim.Time, rsim.Data); hold on; stairs(ysim.Time, ysim.Data); hold off;
grid on; ylabel('Tip angle [deg]'); legend('r', 'y');
title(sprintf('LQG, R = %g, QE = %g I', R, w2));
subplot(2,1,2);
stairs(usim.Time, usim.Data); grid on;
xlabel('Time [s]'); ylabel('u [V]');
fprintf('Peak |u| in simulation = %.2f V\n', max(abs(usim.Data)));

%% Local functions
function plotLocus(p, par, olPoles, olZeros, chosen, parName, ttl)
% Root-square locus in the z-plane: closed-loop poles p(:, i) for each
% value par(i) of the weight, coloured by log10 of the weight.
figure('Name', ttl);
th = linspace(0, 2*pi, 400);
plot(cos(th), sin(th), 'k:'); hold on;
col = repmat(log10(par(:)'), size(p, 1), 1);
scatter(real(p(:)), imag(p(:)), 8, col(:), 'filled');
plot(real(olPoles), imag(olPoles), 'kx', 'MarkerSize', 10, 'LineWidth', 1.5);
if ~isempty(olZeros)
    plot(real(olZeros), imag(olZeros), 'ko', 'MarkerSize', 9, 'LineWidth', 1.5);
end
plot(real(chosen), imag(chosen), 'rp', 'MarkerSize', 12, 'MarkerFaceColor', 'r');
hold off; axis equal; grid on;
cb = colorbar; cb.Label.String = ['log_{10} ' parName];
xlabel('Re z'); ylabel('Im z'); title(ttl);
end
